# Hello Walkers 
<h2>This Is Key Generator Created With NOVA + New Keys + AutoSave Rzlts <br></h2>
Ps: :heavy_exclamation_mark: Dont Forget To Use a Vpn !! (Mostly IP:USA ) :heavy_exclamation_mark:<br>
<h4><b>RIP My Uncle "Rachid AD - 06/07/2021"</b></h4><br>
<h1>Sources</h1><br>
+ Garudaware : https://www.garudaware.id/2018/09/license-key-generator.html<br>
+ SquadCyber : https://www.squadcyber.com/2018/08/license-key-generator.html<br>
+ Termux Tutorial : https://www.termux-tutorial.ga/2018/07/license-key-generator-hidemyass.html<br>
+ Destinymodz ID  : https://www.destinymodz.zone.id/generator-lisensi-vpn-hma-dll<br>
+ Tutoriaz ID: https://www.tutoriaz.zone.id/2018/09/key-generator-termux.html
<h1>Termux</h1><br>
Install Packages<br>
	pkg install python3 & git<br>
Install The Tool<br>
>	pkg install python3 & git
Install The Tool<br>
>	 git clone https://github.com/m4rktn/zeroeye/<br>
Run Zeroeye <br>
>	cd zeroeye<br>
>	python dream.py<br>
<h3>SrceenShot</h3><br>
<h3>My Channel</h3>
<a href="https://t.me/hack151" target="_blank">NOVA</a>
